from django.shortcuts import render
import requests

def job_search(request):
    if request.method == 'POST':
        search_query = request.POST.get('search_query')
        # Assuming DreamCareer API endpoint for job listings is '/job_listings/'
        response = requests.get('http://localhost:8000/job_listings/')
        job_listings = response.json()
        # Filter job listings based on search query
        search_results = [job for job in job_listings if search_query.lower() in job['title'].lower()]
        return render(request, 'search_results.html', {'search_results': search_results})
    return render(request, 'job_search.html')

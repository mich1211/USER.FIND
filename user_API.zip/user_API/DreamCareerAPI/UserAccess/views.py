from django.shortcuts import render
import requests

def index(request):
    if request.method == 'POST':
        username = request.POST.get("username")  # Assuming the form field is 'username'
        password = request.POST.get("password")  # Assuming the form field is 'password'
        api_url = f'http://127.0.0.1:8000/job_listings/'  # Adjust this URL to match your job API endpoint
        response = requests.get(api_url, auth=(username, password))
        job_listings = response.json()
        if response.status_code == 200:
            return render(request, 'job_listings.html', {'job_listings': job_listings})
        else:
            return render(request, 'index.html', {'message': 'Failed to fetch job listings. Please try again!'})
    
        
    return render(request, 'index.html')